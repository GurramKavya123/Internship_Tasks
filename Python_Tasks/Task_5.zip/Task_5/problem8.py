# Q8 - Set .add()
# Link : https://www.hackerrank.com/challenges/py-set-add/problem


n = int(input())
s = set()

for i in range(n):
    country = input().strip()
    s.add(country)

print(len(s))
