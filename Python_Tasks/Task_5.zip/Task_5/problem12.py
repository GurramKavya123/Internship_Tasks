#Q12 - Capitalize!
#Link  : https://www.hackerrank.com/challenges/capitalize/problem



import math
import os
import random
import re
import sys

# Complete the solve function below.
def solve(s):
    return ' '.join(i.capitalize() for i in s.split(' '))

s = input()

result = solve(s)
print(result)