# Q9 - Word Order
# Link : https://www.hackerrank.com/challenges/word-order/problem


n = int(input())
l = []
d = {}

for i in range(n):
    s = input()
    if s not in d:
        l.append(s)
        d[s] = 1
    else:
        d[s] += 1

print(len(l))
print(*[d[i] for i in l])