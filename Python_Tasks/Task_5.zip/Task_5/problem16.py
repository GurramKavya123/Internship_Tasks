# Q16 - Collections.Counter()
# Link : https://www.hackerrank.com/challenges/collections-counter/problem

n = int(input())
shoes = list(map(int, input().split()))
c = int(input())
money = 0

for i in range(c):
    size, price = map(int, input().split())

    if size in shoes:
        money += price
        shoes.remove(size)

print(money)
