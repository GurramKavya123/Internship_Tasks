# Q20 - Piling Up!
# Link :  https://www.hackerrank.com/challenges/piling-up/problem

for _ in range(int(input())):
    n = int(input())
    l = list(map(int, input().split()))

    top = float('inf')

    while l:
        if l[0] >= l[-1]:
            x = l.pop(0)
        else:
            x = l.pop()

        if x > top:
            print("No")
            break

        top = x
    else:
        print("Yes")