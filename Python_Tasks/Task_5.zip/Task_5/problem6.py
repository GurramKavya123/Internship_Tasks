# Q6 - Introduction to Sets
# Link : https://www.hackerrank.com/challenges/py-introduction-to-sets/problem


def average(arr):
     s = set(arr)
     return round(sum(s) / len(s), 3)

if __name__ == '__main__':
    n = int(input())
    arr = list(map(int, input().split()))
    result = average(arr)
    print(result)