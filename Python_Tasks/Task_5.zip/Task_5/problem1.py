# Q1 - Find the Runner-Up Score!
# Link : https://www.hackerrank.com/challenges/find-second-maximum-number-in-a-list/problem


n = int(input())
l = list(map(int, input().split()))

l = list(set(l))
l.sort()

print(l[-2])
