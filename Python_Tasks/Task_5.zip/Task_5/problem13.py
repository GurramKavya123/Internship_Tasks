# Q13 - Nested Lists
# Link : https://www.hackerrank.com/challenges/nested-list/problem


if __name__ == '__main__':
    l=[]
    for _ in range(int(input())):
        name = input()
        score = float(input())
        l.append([name, score])

    grades = sorted(set(i[1] for i in l))
    second = grades[1]

    names = []

    for i in l:
        if i[1] == second:
            names.append(i[0])

    names.sort()
    for i in names:
        print(i)
