# Q7 - Symmetric Difference
# Link : https://www.hackerrank.com/challenges/symmetric-difference/problem


m = int(input())
a = set(map(int, input().split()))

n = int(input())
b = set(map(int, input().split()))

for i in sorted(a.symmetric_difference(b)):
    print(i)
