# Q4 - Loops
# Link : https://www.hackerrank.com/challenges/python-loops/problem

n=int(input())
for i in range(0,n):
    print(i*i)
