# Q20 - Validating the Phone Number
# Link : https://www.hackerrank.com/challenges/validating-the-phone-number/problem

import re

n = int(input())

for i in range(n):
    s = input()
    if re.match(r'^[7-9][0-9]{9}$', s):
        print("YES")
    else:
        print("NO")