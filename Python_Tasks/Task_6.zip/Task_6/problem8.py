# Q8 - Tuples
# Link : https://www.hackerrank.com/challenges/python-tuples/problem

n = int(input())
t = tuple(map(int, input().split()))

value = 0x345678
mult = 1000003
length = n

for x in t:
    value = (value ^ x) * mult
    length -= 1
    mult += 82520 + length + length

value += 97531

if value == -1:
    value = -2

value = ((value + (1 << 63)) % (1 << 64)) - (1 << 63)

print(value)