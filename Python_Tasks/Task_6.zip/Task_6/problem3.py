# Q3 - Python: Division
# Link : https://www.hackerrank.com/challenges/python-division/problem

a=int(input())
b=int(input())
print(a//b)
print(a/b)
