# Q16 - Check Subset
#Link : https://www.hackerrank.com/challenges/py-check-subset/problem

for i in range(int(input())):
    n = int(input())
    a = set(map(int, input().split()))

    m = int(input())
    b = set(map(int, input().split()))

    print(a.issubset(b))