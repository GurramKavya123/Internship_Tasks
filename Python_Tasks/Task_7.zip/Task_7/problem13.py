# Q13 -Sherlock and the Valid String
# Link : https://www.hackerrank.com/challenges/sherlock-and-valid-string/problem


#!/bin/python3

import math
import os
import random
import re
import sys

#
# Complete the 'isValid' function below.
#
# The function is expected to return a STRING.
# The function accepts STRING s as parameter.
#
from collections import Counter
def isValid(s):
    # Write your code here
    freq = list(Counter(s).values())
    unique = set(freq)

    if len(unique) == 1:
        return "YES"

    if len(unique) == 2:
        a, b = sorted(unique)

        if freq.count(a) == 1 and a == 1:
            return "YES"

        if freq.count(b) == 1 and b - a == 1:
            return "YES"

    return "NO"
if __name__ == '__main__':
    fptr = open(os.environ['OUTPUT_PATH'], 'w')

    s = input()

    result = isValid(s)

    fptr.write(result + '\n')

    fptr.close()
