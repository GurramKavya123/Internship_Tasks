# Q17 - Separate the Numbers
#Link : https://www.hackerrank.com/challenges/separate-the-numbers/problem


#!/bin/python3

import math
import os
import random
import re
import sys

#
# Complete the 'separateNumbers' function below.
#
# The function accepts STRING s as parameter.
#

def separateNumbers(s):
    # Write your code here
     for i in range(1, len(s) // 2 + 1):
        first = s[:i]

        if first[0] == '0':
            continue

        num = int(first)
        temp = ""

        while len(temp) < len(s):
            temp += str(num)
            num += 1

        if temp == s:
            print("YES", first)
            return

     print("NO")

if __name__ == '__main__':
    q = int(input().strip())

    for q_itr in range(q):
        s = input()

        separateNumbers(s)
