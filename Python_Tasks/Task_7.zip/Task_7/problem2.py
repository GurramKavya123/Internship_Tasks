# Q2 - The Captain's Room
# Link : https://www.hackerrank.com/challenges/py-the-captains-room/problem



k = int(input())
rooms = list(map(int, input().split()))

s = set(rooms)

print((sum(s) * k - sum(rooms)) // (k - 1))