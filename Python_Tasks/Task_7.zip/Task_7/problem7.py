# Q7 - Alphabet Rangoli
#Link : https://www.hackerrank.com/challenges/alphabet-rangoli/problem


import string
def print_rangoli(size):
    # your code goes here
    
     alpha = string.ascii_lowercase

     for i in range(size):
        s = alpha[size-1:size-i-1:-1] + alpha[size-i-1:size]
        line = "-".join(s)
        print(line.center(4 * size - 3, "-"))

     for i in range(size-2, -1, -1):
        s = alpha[size-1:size-i-1:-1] + alpha[size-i-1:size]
        line = "-".join(s)
        print(line.center(4 * size - 3, "-"))
if __name__ == '__main__':
    n = int(input())
    print_rangoli(n)