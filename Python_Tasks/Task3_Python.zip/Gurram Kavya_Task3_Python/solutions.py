# Q1. Find the Frequency of Each Word in a Sentence
def fun1(s):
    d={}
    for i in s.split():
        if i in d:
            d[i]+=1
        else:
            d[i]=1
    return d

# Q2. Find the Frequency of Each Character in a Word
def fun2(w):
    d={}
    for i in w:
        if i in d:
            d[i]+=1
        else:
            d[i]=1
    return d

# Q3. Find the First Non-Repeating Character in a Word
def fun3(w):
    for i in w:
        if w.count(i)==1:
            return i
    return None

# Q4. Check Whether Two Strings Are Anagrams
def fun4(w,w1):
    if sorted(w)==sorted(w1):
        return True
    else:
        return False

# Q5. Find the First Repeating Character in a String
def fun5(s):
    for i in s:
        if s.count(i) > 1:
            return i
    return None

# Q6. Move All Zeros to the End of a List
def fun6(l):
    a=[]
    count=0
    for i in l:
        if i==0:
            count+=1
        else:
            a.append(i)
    for i in range(count):
        a.append(0)
    return a

# Q7. Find the Second Highest Distinct Number in a List
def fun7(l):
    a=[]
    for i in l:
        if i not in a:
            a.append(i)
    a.sort()
    if len(a) < 2:
        return None
    return a[-2]

# Q8. Remove Duplicates Without Changing the Original Order
def fun8(l):
    a = []
    for i in l:
        if i not in a:
            a.append(i)
    return a

# Find the Missing Number from 1 to N
def fun9(nums,N):
    for i in range(1,N+1):
        if i not in nums:
            return i
    return None

# Q10. Find Two Numbers Whose Sum Equals a Target
def fun10(l, target):
    for i in range(len(l)):
        for j in range(i + 1, len(l)):
            if l[i] + l[j] == target:
                return [l[i], l[j]]
    return []

# Q11. Find the Number Closest to Zero
def fun11(l):
    a = l[0]
    for i in l:
        if abs(i) < abs(a):
            a = i
        elif abs(i) == abs(a) and i > a:
            a = i
    return a

# Q12. Find Common Elements Between Two Lists
def fun12(l1, l2):
    a = []
    for i in l1:
        if i in l2 and i not in a:
            a.append(i)
    return a

# Q13. Rotate a List to the Right by K Positions
def fun13(l, k):
    if len(l) == 0:
        return l
    k = k % len(l)
    return l[-k:] + l[:-k] if k != 0 else l

# Q14. Find the Maximum Sum of Two Consecutive Elements
def fun14(l):
    a = l[0] + l[1]
    for i in range(len(l) - 1):
        if l[i] + l[i + 1] > a:
            a = l[i] + l[i + 1]
    return a

#Q15. Find All Pairs of Numbers Whose Sum Equals a Target
def fun15(l, target):
    a = []
    for i in range(len(l)):
        for j in range(i + 1, len(l)):
            if l[i] + l[j] == target:
                p = sorted([l[i], l[j]])
                if p not in a:
                    a.append(p)
    a.sort()
    return a  