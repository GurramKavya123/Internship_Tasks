
from solutions import *

print("Q1:", fun1("python is easy and python is powerful"))
print("Q2:", fun2("banana"))
print("Q3:", fun3("swiss"))
print("Q4:", fun4("listen", "silent"))
print("Q5:", fun5("programming"))
print("Q6:", fun6([0, 3, 0, 1, 2, 0, 4]))
print("Q7:", fun7([10, 20, 40, 30, 40, 20]))
print("Q8:", fun8([4, 2, 4, 5, 2, 7, 5]))
print("Q9:", fun9([1, 2, 4, 5, 6], 6))
print("Q10:", fun10([2, 7, 11, 15], 9))
print("Q11:", fun11([-8, -3, 2, 5, -2]))
print("Q12:", fun12([1, 2, 3, 4, 5], [3, 4, 5, 6, 7]))
print("Q13:", fun13([1, 2, 3, 4, 5], 2))
print("Q14:", fun14([4, 7, 2, 9, 5]))
print("Q15:", fun15([2, 4, 3, 5, 7, 8, 1], 9))
